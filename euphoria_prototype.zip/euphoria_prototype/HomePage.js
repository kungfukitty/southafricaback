import React from 'react';

export default function HomePage() {
  return (
    <div className="bg-black text-white min-h-screen font-sans">
      <header className="text-center py-10">
        <h1 className="text-5xl font-bold text-purple-500">Euphoria</h1>
        <p className="text-lg mt-2">Feel the Frequency. Live the Night.</p>
      </header>
      <section className="px-6 py-10">
        <h2 className="text-3xl font-semibold mb-4">Upcoming Events</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-gray-800 p-4 rounded-lg">
            <h3 className="text-xl font-bold">Jozi Rooftop Party</h3>
            <p className="mt-2">Date: July 15, 2024</p>
            <button className="mt-4 bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">Buy Tickets</button>
          </div>
          <div className="bg-gray-800 p-4 rounded-lg">
            <h3 className="text-xl font-bold">Afrobeat Night</h3>
            <p className="mt-2">Date: August 5, 2024</p>
            <button className="mt-4 bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">Buy Tickets</button>
          </div>
        </div>
      </section>
      <footer className="text-center py-6">
        <p>Follow us:</p>
        <div className="flex justify-center space-x-4 mt-2">
          <a href="https://instagram.com" className="text-purple-400 hover:text-purple-600">Instagram</a>
          <a href="https://youtube.com" className="text-purple-400 hover:text-purple-600">YouTube</a>
          <a href="https://facebook.com" className="text-purple-400 hover:text-purple-600">Facebook</a>
        </div>
      </footer>
    </div>
  );
}
